package com.klef.jfsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtracircularSdpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtracircularSdpApplication.class, args);
		System.out.println("Project Running...!!!");
	}

}
